# Godot MCP Development Tool

Godot MCP is the recommended development-time adapter for inspecting and
authoring the Godot client when a connected editor is available. It is not a
runtime dependency and must never become an alternate source of simulator
authority.

## Scope / Trigger

Use this guide when a task edits or validates `godot/client/` through the connected Godot editor. Read-only inspection should happen before scene or script edits.

## Connection Check

Call the editor state operation:

```json
{"op":"state"}
```

through `mcp__godot_ai__editor_manage`. A successful connection returns a structured result containing at least `godot_version`, `project_name`, `readiness`, `current_scene`, and `game_status`. Record the observed project name/version when reporting a connection test. `readiness: "no_scene"` means the MCP connection works; it only indicates that no scene is open.

## Tool Boundaries

- Prefer read operations first: editor state, scene hierarchy, node properties, filesystem/resource inspection, and logs.
- Prefer MCP over blind textual scene editing when it can inspect or perform the
  same scoped scene/resource operation safely and structurally.
- Use scene/node/script/resource/UI tools only for an explicitly scoped implementation task.
- Keep scene paths project-relative (`res://...`) and target the active session unless a specific `session_id` is required.
- Use undoable authoring operations where available; inspect the result and the working-tree diff after writes.
- Treat `editor_reload_plugin`, editor quit, game launch, and other lifecycle operations as explicit user-authorized actions.

### Project settings gotcha

Some startup-sensitive settings, including `application/run/main_scene`, are intentionally rejected by the MCP `project_manage(settings_set)` safety guard. When a scoped task must change one, edit `project.godot` through the normal project change path, then validate with a headless Godot import/run or restart the editor before relying on the live settings cache. A stale live setting read is not evidence that the file change failed.

### GLB embedded-texture policy

For a user-supplied `.glb` whose textures are already embedded, keep the asset self-contained:

- Track adjacent `.glb.import` metadata with `gltf/embedded_image_handling=2` (Embed as Basis Universal).
- Do not commit PNG sidecars produced by default extract-textures mode, and do not treat `.godot/imported/` as source input.
- After changing import mode, force a filesystem scan or restart the editor before reading logs; a live editor can retain stale reimport entries.
- Validate source/destination byte identity and SHA-256 separately from import success.

Good: preserve the supplied GLB as the single visual source, record its hash and node mapping in a project manifest, and validate the imported hierarchy with a headless test.

Bad: hand-copy extracted textures into the repository, infer pivots from mesh names at runtime, or treat a successful editor preview as proof of source-byte identity.

## Cross-Layer Contract

The MCP edits only the Godot presentation client. In the standalone product,
Godot/Jolt is authoritative for lifecycle, joint state, terrain layers, bucket
inventory and local truth; Python remains an explicit compatibility authority
or optional observational gateway. MCP-assisted Godot code may consume
HTTP/WebSocket snapshots and patches in those explicit modes, but must not write
authoritative transforms, terrain heights, bucket volume, or replay cursors back
to Python.

## Validation & Error Matrix

| Condition | Required response |
|---|---|
| MCP call returns a transport/tool error | Stop authoring, report the error, and retry only after connection state is rechecked. |
| `readiness: "no_scene"` | Connection is healthy; open or create the intended scene before scene-specific operations. |
| No active Godot session | Do not guess a session; ask for the editor to be opened/reconnected. |
| Game helper is not ready | Do not use game evaluation; inspect editor state or stop/relaunch the game. |
| Stale terrain/replay generation | Discard the derived client update; never overwrite newer state. |
| Backend/protocol files changed | Run the backend `pixi run verify` gate and inspect protocol compatibility. |

## Good / Base / Bad Cases

- Good: call `editor_manage(state)`, confirm the project/session, inspect the scene, make one scoped undoable change, then verify the resulting file/diff.
- Base: use MCP only for read-only inspection while the Godot scene is still being designed.
- Bad: use MCP to make Godot physics authoritative, create a second terrain store, or launch broad destructive editor operations without explicit scope.

## Tests Required

- Connection smoke: `editor_manage(state)` succeeds and reports `project_name == "ExcavatorSim"`.
- Scene authoring: reopen/inspect the edited scene and verify the expected node paths and properties through MCP.
- Client lifecycle changes: exercise missing scene, reconnect, stale generation, reset, seek, and Return Live transitions where applicable.
- Cross-layer changes: run `pixi run verify`; preserve protocol schema/version and deterministic backend tests.
- Select and budget these checks through `validation-budget.md`. MCP-assisted
  editor inspection, structured authoring, and objective state verification
  remain recommended Agent development activities. Launching the game for
  subjective visual or interaction judgment is human-owned by default; routine
  automated tests stay focused and headless.

## Verification runner boundary

The bundled MCP test handler discovers only `res://tests/test_*.gd` scripts that
instantiate `McpTestSuite`. The ExcavatorSim product contracts intentionally use
standalone `SceneTree` scripts (for example `motion_client_test.gd` and
`release_candidate_test.gd`) so they can run without the editor addon or a
running service. For routine changes, invoke the single relevant standalone
script (or focused test command) rather than
`godot/client/tests/run_standalone_matrix.ps1`. The full matrix is reserved for
the escalation triggers in `validation-budget.md`. MCP-driven **game runtime
visual/interaction smoke** is a human-owned milestone unless the user explicitly
requests Agent-driven runtime operation. This does not restrict normal MCP
editor inspection or authoring. Follow the focused sequence in
`docs/release-candidate.md` only when such a runtime milestone is active.

The project baseline is a 1920x1080 viewport with responsive `canvas_items` /
`expand` stretch. A smaller MCP capture is a resized observation, not evidence
that the project baseline changed; verify the persisted settings with
`project_manage(settings_get)` after the editor has reloaded the project.

## Wrong vs Correct

### Wrong

Use Godot MCP to write a locally simulated pose or terrain height back into the Python service as if it were authoritative.

### Correct

Use MCP to create or inspect the Godot presentation nodes, consume the Python snapshot/patch, and discard or rebuild derived state when the authority generation changes.

## Design Decision

Godot MCP is documented as a development tool rather than a product dependency. This keeps editor automation replaceable while preserving the Python authority and the existing HTTP/WebSocket compatibility boundary.
