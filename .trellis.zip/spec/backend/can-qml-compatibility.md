# QML-Compatible CAN Projection

## 1. Scope And Trigger

This contract applies to the SY135/SY80U/SY155W built-in profiles selected by default
and explicit `--compat-profile` launches of `tools/can_gateway/gateway.py`.
QML and its C++ protocol/kinematics implementation are the immutable semantic
authority. Godot remains the simulation authority and the Python gateway
projects Godot truth into the CAN fields that the QML call path actually consumes.
Models without a built-in or explicit profile retain the byte-compatible legacy
path.

## 2. Public Interfaces And Signatures

- `--compat-profile PATH|builtin:qml-{sy135,sy80u,sy155w}-ground-truth` selects a strict
  TOML mapping profile; SY135/SY80U/SY155W select their built-in profile by default.
  `--qml-calibration PATH` explicitly overrides the calibration file.
- `load_qml_profile(...)` validates version, target, model, frame declarations,
  required calibration fields, finite numeric values and positive lengths before
  any UDP or CAN transport is opened. Calibration has no hash binding, allowing
  operators to replace GuideSystem-compatible TOML without regenerating profiles.
- `QmlCanMapper.project(MachineState)` returns the body IMU fields, work-equipment
  fields, GNSS A/B fields and RTK status for one strictly increasing physics
  tick.
- `emit_frames(...)` pre-encodes the complete due frame family before appending
  any frame to the sink.
- Both legacy and calibrated telemetry reject non-finite physical values at
  ingress; packet shape/tick types come from the binary layout. Preserve the
  calibrated mapper's existing quaternion normalization without a unit-norm
  admission threshold. Sample preparation has an exception boundary
  before any sink writes: failures discard the whole due family and preserve
  projection history and scheduler state. A following valid sample can resume on
  the same PC001 connection. Rollback preserves only the two velocity-history
  fields. Unexpected preparation bugs retain a traceback distinct from ordinary
  data rejection. Transport errors remain separate from bad samples.
- Godot CTN1 telemetry v2 retains the 176-byte layout and assigns the reserved
  header uint16 to model identity (1=SY135, 2=SY80U). CTNC/CTNK remain v1.
  Gateway accepts legacy CTN1 v1 using its CLI model; v2 selects a matching
  codec/profile per sample. Unknown model IDs are rejected.
- SY155W uses model ID 3 and CTN1 v3 (204 bytes), appending boom2 after the
  five existing pose records and before the unchanged scalar tail. Versions
  1/2 retain their 176-byte layout; v3 requires model 3 and vice versa.
  Its isolated DBC derives from owner-specified SY135C_RT can3/can4 snapshots.
  Body/boom/arm/bucket IDs are 18F00000/18F10000/18F20000/18F30000; extra
  boom2 is18F40000. Signed LE Roll/Pitch at0.01deg, unsigned Yaw, zero offset,
  valid zero readings, channel3/DLC8. Parser negates Pitch only. Second-boom
  pitch is cumulative boom+fold; arm is relative to boom2. Circular angles wrap.
  GNSS09F80230 gives equipment heading in radians and speed;09F80530 uses
  eight classic-CAN fragments1..8 carrying51 BE bytes in a virtual64-byte DBC
  buffer. First header01/33, last fourFF padding, no transfer-ID bits. can4 maps
  to ch2. No old slew/A000..A900 output for155W. SocketCAN coalesces whole
  transfers and drops unsent remainder on congestion; PC001 queues whole groups.
  Zero/calibration conventions retain the requested135 physical mapping while
  RT DBC owns bytes. Other model bytes remain unchanged.
  The default neutral XTR13/GB12 tip ray defines bucket alignment; independent
  attachment articulation is outside this protocol. Receiver implementation
  of the extra IMU is required; sender tests do not imply receiver GUI acceptance.
- SY135 NEO is a visual variant: Godot publishes it as wire model 1 (SY135),
  using the existing SY135 profile and DBC. SY135/NEO switches must preserve
  the gateway model, PC001 socket and completed handshake.

## 3. Semantic Contracts

- All profile frame declarations are `upper`. The fixed Godot-to-QML basis and
  QML root alignment are applied before extracting QML body P/R/H.
- Gateway wire values invert the complete QML runtime call path, including
  `GuidancePeriodicService`'s body pitch/roll remap and the active calibration,
  so `lib_kin` reconstructs the projected Godot pose.
- Main antenna position obeys `GNSSA = O - Exca * GO`. Velocity is the finite
  difference of successive GNSSA positions. The vice antenna uses the explicit
  profile mount offset; it is never inferred silently.
- SY80U uses its own hash-bound DBC directory and persisted reference calibration.
  Its IMU is signed int16 with zero offset; the extra VAL body-axis swap is
  reversed separately. Extract upper-to-boom as Ry(side) Rx(boom), remove side
  before local-X validation, and emit side as DBC SWING (parser and QML each
  negate it). Slew DLC is 2. Model transitions reset projection history and
  schedulers, rebuild the console, retire old SocketCAN frames/custom schedules,
  and close/reopen PC001 transport on the same port with a fresh handshake.
  Old TCP queues are discarded. Per-model operator persistence is isolated.
- SY80 calibration binds orientation parity to the actual persisted receiver
  values, not uncalibrated factory defaults. Do not claim model dimensions or
  tooth positions agree when receiver lengths differ from the simulator rig.
- Boom, arm and bucket inputs come from adjacent-link local-X twist relative to
  the profile neutral alignment. Off-axis residuals, gimbal singularities and
  unreachable four-bar branches are rejected.
- Profile alignment values are QML kinematic outputs, not raw IMU calibration
  offsets. The QML 3D renderer applies local X rotations as
  `(boomPhi, armPhi + 180 degrees, bktPhi + 180 degrees)`. Therefore the SY135
  Godot neutral relations `(+35, -90, -50)` require QML neutral targets
  `(+35, +90, +130)` before joint deltas are added.
- QML profile math owns physical projection, but the approved DBC owns wire
  layout in every profile. A800 `VelE/VelN/VelU/Vel` are signed little-endian;
  there is no compatibility-profile byte-order exception.
- Raw CAN IDs above `0x7ff` are packed with `CAN_EFF_FLAG`; standard IDs such as
  travel `0x256` remain standard. Already flagged valid extended IDs are
  preserved.
- Each startup reads `config/calibration_sy135.toml` or
  `config/calibration_sy80u.toml` or `config/calibration_sy155w.toml` beside the gateway executable (beside the script
  in source runs), independent of the working directory and PyInstaller extraction
  directory. Built-in profiles remain embedded; editable calibrations do not.
  Custom profiles resolve `calibration_file` relative to their own directory.
  GuideSystem's `[angle]`, `[imu_car]`, `[imu_component]`, `[length]`, `[offset]`
  schema accepts UTF-8 BOM and ignores extra fields. There is no runtime watcher
  or missing-file fallback. Log the profile version, model and calibration path.
  DBC hash enforcement and build/provenance hashes remain unchanged.

## 4. Rejection And Fallback Matrix

| Condition | Required behavior |
|---|---|
| Profile/calibration missing, malformed, invalid numeric values or wrong profile model | Fail before opening transport |
| Non-finite pose or origin | Reject the sample; emit no partial family |
| Off-axis joint rotation, gimbal singularity or unreachable bucket branch | Reject the sample with an actionable diagnostic |
| Duplicate or decreasing physics tick | Reject the sample; do not reuse a tick-only cache |
| Profile mapping fails at runtime | Drop that sample; never fall back to legacy projection |
| No explicit profile for SY135/SY80U/SY155W | Load the matching built-in profile and external per-model calibration |
| Other model without a compatibility profile | Use the unchanged legacy projection and encoding path |

## 5. Examples

Good: Godot publishes an SY135 post-step `upper` transform and link transforms
at tick 101. The gateway validates the bundled profile, projects the sample once,
pre-encodes all due frames, and QML's parser plus calibration reconstruct the
same root and joint pose within the locked numeric tolerances.

Base: at the SY135 neutral pose, QML receives kinematic outputs `(35, 90, 130)`;
its renderer applies `(35, 270, 310)`, which are the same signed local rotations
as Godot `(35, -90, -50)`.

Boundary: a legal bucket pose near either end of the configured monotonic
four-bar interval is accepted only if forward substitution reproduces the
measured adjacent twist.

Bad: a sample contains `NaN` in the ENU origin after body and joint frames were
prepared. The gateway must emit zero frames for that sample, not a partial IMU
or work-equipment family.

## 6. Verification Requirements

- Pure mapping tests cover neutral pose, Godot cardinal yaw, every joint in both
  directions, calibration inverse, GNSSA round-trip, four-bar forward
  substitution, gimbal/off-axis/range rejection, non-finite input and monotonic
  ticks.
- Neutral and isolated-joint mapping tests must independently apply the QML
  renderer's `+180 degree` arm/bucket offsets and compare each resulting local
  rotation with the corresponding Godot adjacent-frame relation. A
  `Sensor2Ang` inverse/forward round-trip alone is insufficient because it can
  prove a wrong neutral alignment self-consistent.
- Encoder tests compare against strict cantools encoding from the approved DBC,
  including an explicit A800 signed little-endian assertion in profile mode.
- SocketCAN and PC001 tests cover extended IDs A900 and the four Ruifen IDs plus
  standard travel ID `0x256`.
- Godot headless tests compare authoritative post-step transforms,
  presentation transforms, joint scalars and the emitted CTN1 packet for neutral
  and one positive checkpoint per joint.
- `tests/test_qml_compat.py` covers per-model source/frozen config lookup,
  explicit overrides, BOM/extra fields, restart adoption and invalid-file rejection.
  `smoke_frozen_gateway.py` starts a Windows onefile package from a different
  working directory, edits each model calibration in a temporary package copy and
  verifies changed CAN payloads after restart. Both platform distributions require
  all three config files. The Python suite and focused Godot CAN E2E tests must pass
  before completion.

## 7. Common Wrong And Correct Patterns

Wrong: encode Godot Euler angles directly, use a generic forward-vector
convention, or compare only decoded CAN numbers. Correct: trace the entire QML
parser/service/calibration/kinematics composition and implement its mathematical
inverse.

Wrong: let the compatibility mapper override A800 byte order. Correct: the
mapper projects physical values and the shared DBC codec alone encodes the
little-endian A800 wire payload.

Wrong: emit frames as each field is calculated and silently recover with legacy
values. Correct: validate and pre-encode the whole due family, then append it
atomically from the mapper's perspective; profile errors drop the sample.

Wrong: use the three component IMU calibration offsets, or the result of feeding
zero pitch to `Sensor2Ang`, as the model's neutral QML joint outputs. Correct:
derive profile neutral outputs from the QML renderer's local-pivot equations and
the Godot adjacent-frame neutral relations, then validate both neutral and
isolated motion after the renderer offsets are applied.
